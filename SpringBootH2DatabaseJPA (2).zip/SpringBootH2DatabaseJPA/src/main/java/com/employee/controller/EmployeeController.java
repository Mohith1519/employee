package com.employee.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employee.model.Employee;
import com.employee.service.EmployeeServiceImpl;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	@Autowired
	public EmployeeServiceImpl employeeServiceImpl;
	@PostMapping("/save")
	public void save(@RequestBody Employee employee) {
		employeeServiceImpl.save(employee);
	}
	@GetMapping("/getAllEmployees")
	public List<Employee> getAllEmployees(){
		List<Employee> employees=employeeServiceImpl.getAllEmployees();
		return employees;
	}
	@GetMapping("/getAllEmployeesByDepartment/{department}")
	public List<Employee> getAllEmployeesByDepartment(@PathVariable String department){
		List<Employee> employees=employeeServiceImpl.getAllEmployeesByDepartment(department);
		return employees;	
	}
	@GetMapping("/getEmployeeById/{id}")x
	public Employee getEmployeeById(@PathVariable(value="id") int id) {
		return employeeServiceImpl.getById(id);
	}
	@DeleteMapping("/deleteById/{id}")
	public void employee(@PathVariable int id) {
		 employeeServiceImpl.deleteById(id);
	}
	
}
