package com.employee.service;

import java.util.List;

import com.employee.model.Employee;

public interface EmployeeService {
	public void save(Employee employee);
	public List<Employee> getAllEmployees();
	public Employee getById(int id);
	public List<Employee> getAllEmployeesByDepartment(String department);
	public void deleteById(int id);
}
